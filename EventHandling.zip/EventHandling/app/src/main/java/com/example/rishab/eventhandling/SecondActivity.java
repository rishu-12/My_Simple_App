package com.example.rishab.eventhandling;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        final TextView txt=findViewById(R.id.view1);
        final Button btn=findViewById(R.id.btn1);
        txt.setText(getIntent().getStringExtra("Name :"));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(view.getContext(),MainActivity.class);
                startActivity(i);
            }
        });
    }
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        if(id==R.id.homeAsUp){
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
